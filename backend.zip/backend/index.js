require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('MongoDB conectado!'))
  .catch(err => console.error('Erro ao conectar no MongoDB:', err));

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Pasta onde as imagens serão armazenadas
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`); // Nome único para cada arquivo
  },
});

const upload = multer({ storage });

// Endpoint para upload de imagens
app.post('/upload', upload.single('image'), (req, res) => {
  console.log('Requisição recebida na rota /upload');
  console.log('Arquivo recebido:', req.file);
  try {
    if (!req.file) {
      console.error('Nenhum arquivo foi enviado.');
      return res.status(400).json({ error: 'Nenhum arquivo foi enviado.' });
    }

    const imagePath = `/uploads/${req.file.filename}`;
    console.log('Caminho da imagem salva:', imagePath);

    const fullImageUrl = `${req.protocol}://${req.get('host')}${imagePath}`;
    console.log('URL completa da imagem:', fullImageUrl);

    res.status(200).json({
      message: 'Upload realizado com sucesso!',
      imageUrl: fullImageUrl,
    });
  } catch (err) {
    console.error('Erro ao fazer upload da imagem:', err);
    res.status(500).json({ error: 'Erro ao fazer upload da imagem' });
  }
});

// Certifique-se de servir arquivos estáticos da pasta uploads
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Importar models
const Space = require('./models/Space');
const User = require('./models/User');
const Reservation = require('./models/reservartion');
const Rating = require('./models/rating');

// Rotas para espaços esportivos
app.get('/spaces', async (req, res) => {
  try {
    const spaces = await Space.find();
    const updatedSpaces = spaces.map(space => {
      const fullImageUrl = space.imageUrl.replace( '');
      return {
        ...space.toObject(),
        imageUrl: fullImageUrl,
      };
    });
    res.json(updatedSpaces);
  } catch (err) {
    console.error('Erro ao buscar espaços:', err);
    res.status(500).json({ error: 'Erro ao buscar espaços' });
  }
});

// Endpoint para criar um espaço com upload de imagem
app.post('/spaces', upload.single('image'), async (req, res) => {
  try {
    console.log('Requisição recebida no endpoint /spaces');
    console.log('Dados do corpo:', req.body);
    console.log('Arquivo recebido:', req.file);

    const { name, sportType, pricePerHour, address, description, hostName } = req.body;

    if (!req.file) {
      console.error('Nenhum arquivo foi enviado.');
      return res.status(400).json({ error: 'A imagem é obrigatória.' });
    }

    const imageUrl = `/uploads/${req.file.filename}`;

    const space = new Space({
      name,
      sportType,
      pricePerHour,
      address,
      description,
      hostName,
      imageUrl,
    });

    await space.save();
    console.log('Espaço criado com sucesso:', space);
    res.status(201).json(space);
  } catch (err) {
    console.error('Erro ao criar espaço:', err);
    res.status(500).json({ error: 'Erro ao criar espaço' });
  }
});

// Rotas para usuários
app.get('/users', async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar usuários' });
  }
});

app.post('/users', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json(user);
  } catch (err) {
    res.status(400).json({ error: 'Erro ao cadastrar usuário' });
  }
});

// Rotas para reservas
app.get('/reservations', async (req, res) => {
  try {
    const reservations = await Reservation.find().populate('userId').populate('spaceId');
    res.json(reservations);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar reservas' });
  }
});

app.post('/reservations', async (req, res) => {
  try {
    const reservation = new Reservation(req.body);
    await reservation.save();
    res.status(201).json(reservation);
  } catch (err) {
    res.status(400).json({ error: 'Erro ao cadastrar reserva' });
  }
});

// Rotas para comentários/ratings
app.get('/ratings', async (req, res) => {
  try {
    const ratings = await Rating.find().populate('userId').populate('spaceId');
    res.json(ratings);
  } catch (err) {
    res.status(500).json({ error: 'Erro ao buscar avaliações' });
  }
});

app.post('/ratings', async (req, res) => {
  try {
    const rating = new Rating(req.body);
    await rating.save();
    res.status(201).json(rating);
  } catch (err) {
    res.status(400).json({ error: 'Erro ao cadastrar avaliação' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});